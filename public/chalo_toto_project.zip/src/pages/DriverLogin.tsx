/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DriverLogin } from './RoleLogins';
export default DriverLogin;
