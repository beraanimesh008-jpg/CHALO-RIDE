/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { db } from './firebase';
import { doc, getDoc, setDoc, updateDoc, collection, addDoc, query, where, getDocs, limit, runTransaction } from 'firebase/firestore';
import { 
  DriverWallet, 
  CommissionTransaction, 
  UserProfile, 
  Ride, 
  RideStatus,
  DriverVerificationStatus, 
  DriverAccessReason, 
  DriverAccessEvaluation,
  AppSettings
} from '../types';

export const DEFAULT_COMMISSION_PERCENT = 10;
export const CHALO_COMMISSION_PERCENT = 10;
export const DEFAULT_COMMISSION_BLOCK_LIMIT = 100; // Threshold (₹) where driver is blocked from receiving new rides
export const MIN_WALLET_BALANCE_REQUIRED = -100;

/**
 * Resolves the final total booking amount of a completed ride.
 * Checks finalFare, acceptedFare, userOfferedFare, and baseFare + passengerExtraCharge.
 */
export function getRideBookingAmount(ride: Partial<Ride>, explicitFare?: number): number {
  if (typeof explicitFare === 'number' && explicitFare > 0) {
    return Math.round(explicitFare);
  }
  if (typeof ride.finalFare === 'number' && ride.finalFare > 0) {
    return Math.round(ride.finalFare);
  }
  if (typeof ride.acceptedFare === 'number' && ride.acceptedFare > 0) {
    return Math.round(ride.acceptedFare);
  }
  if (typeof ride.userOfferedFare === 'number' && ride.userOfferedFare > 0) {
    return Math.round(ride.userOfferedFare);
  }
  if (typeof ride.baseFare === 'number' && ride.baseFare > 0) {
    return Math.round(ride.baseFare + (ride.passengerExtraCharge || 0));
  }
  return 0;
}

/**
 * Calculates Chalo Platform Commission:
 * Chalo Commission = Final Booking Amount × 10%
 * Examples: ₹100 booking = ₹10 commission, ₹150 booking = ₹15, ₹200 booking = ₹20
 */
export function calculateChaloCommission(bookingAmount: number): number {
  const safeAmount = Math.max(0, Number(bookingAmount) || 0);
  return Math.round((safeAmount * CHALO_COMMISSION_PERCENT) / 100);
}

/**
 * Fetch global app settings for commission rate and block limit
 */
export async function getGlobalCommissionSettings(): Promise<{ commissionRatePercent: number; commissionBlockLimit: number }> {
  try {
    const settingsDoc = await getDoc(doc(db, 'app_settings', 'global'));
    if (settingsDoc.exists()) {
      const data = settingsDoc.data() as Partial<AppSettings>;
      return {
        commissionRatePercent: data.commissionRatePercent ?? DEFAULT_COMMISSION_PERCENT,
        commissionBlockLimit: data.commissionBlockLimit ?? DEFAULT_COMMISSION_BLOCK_LIMIT
      };
    }
  } catch (err) {
    console.warn('Could not fetch app_settings/global:', err);
  }
  return {
    commissionRatePercent: DEFAULT_COMMISSION_PERCENT,
    commissionBlockLimit: DEFAULT_COMMISSION_BLOCK_LIMIT
  };
}

/**
 * Evaluates driver ride access status with all 7 business rules:
 * 1. Driver Approval Status == APPROVED
 * 2. Driver Online == true
 * 3. Driver Available == true (not currently busy on an active trip)
 * 4. Driver Inside Service Area Polygon == true
 * 5. Driver Admin Ride Control == ACTIVE (not SUSPENDED by Admin)
 * 6. Driver Commission Balance < Commission Block Limit (₹100)
 */
export function evaluateDriverRideAccess(
  driver: Partial<UserProfile> | null | undefined,
  activeRide: Ride | null = null,
  serviceArea?: { enabled: boolean; polygon: any[] },
  isDriverInside: boolean = true
): DriverAccessEvaluation {
  const balance = driver?.commissionBalance ?? 0;
  const blockLimit = driver?.commissionBlockLimit ?? DEFAULT_COMMISSION_BLOCK_LIMIT;
  const isCommissionLimitReached = balance >= blockLimit;
  const isAdminSuspended = driver?.adminRideAccess === 'SUSPENDED';

  // 1. Verification status
  if (!driver || driver.driverVerificationStatus !== DriverVerificationStatus.APPROVED) {
    return {
      canReceiveNewRides: false,
      rideAccessStatus: 'BLOCKED',
      reason: 'Driver Not Approved',
      bengaliReason: 'ড্রাইভার ভেরিফিকেশন অপেক্ষমান / ড্রাইভার অনুমোদিত নয়',
      isCommissionLimitReached,
      isAdminSuspended,
      commissionBalance: balance,
      commissionBlockLimit: blockLimit
    };
  }

  // 2. Online status
  if (!driver.isOnline) {
    return {
      canReceiveNewRides: false,
      rideAccessStatus: 'BLOCKED',
      reason: 'Driver Offline',
      bengaliReason: 'ড্রাইভার অফলাইনে আছেন (Online সুইচ চালু করুন)',
      isCommissionLimitReached,
      isAdminSuspended,
      commissionBalance: balance,
      commissionBlockLimit: blockLimit
    };
  }

  // 3. Busy on active trip
  if (activeRide) {
    return {
      canReceiveNewRides: false,
      rideAccessStatus: 'BLOCKED',
      reason: 'Busy',
      bengaliReason: 'চলমান ট্রিপে ব্যস্ত আছেন (ট্রিপ শেষ হলে আবার নতুন রাইড পাবেন)',
      isCommissionLimitReached,
      isAdminSuspended,
      commissionBalance: balance,
      commissionBlockLimit: blockLimit
    };
  }

  // 4. Outside service area polygon
  if (serviceArea?.enabled && !isDriverInside) {
    return {
      canReceiveNewRides: false,
      rideAccessStatus: 'BLOCKED',
      reason: 'Outside Service Area',
      bengaliReason: 'সার্ভিস এলাকার বাইরে অবস্থান করছেন',
      isCommissionLimitReached,
      isAdminSuspended,
      commissionBalance: balance,
      commissionBlockLimit: blockLimit
    };
  }

  // 5. Admin manual suspension
  if (isAdminSuspended) {
    return {
      canReceiveNewRides: false,
      rideAccessStatus: 'SUSPENDED',
      reason: 'Admin Suspended',
      bengaliReason: 'অ্যাডমিন কর্তৃক নতুন রাইড গ্রহণ স্থগিত করা হয়েছে',
      isCommissionLimitReached,
      isAdminSuspended: true,
      commissionBalance: balance,
      commissionBlockLimit: blockLimit
    };
  }

  // 6. Commission threshold reached
  if (isCommissionLimitReached) {
    return {
      canReceiveNewRides: false,
      rideAccessStatus: 'BLOCKED',
      reason: 'Commission Limit Reached',
      bengaliReason: `বকেয়া কমিশন সীমা (₹${blockLimit}) পৌঁছেছে - কমিশন পরিশোধ করুন`,
      isCommissionLimitReached: true,
      isAdminSuspended: false,
      commissionBalance: balance,
      commissionBlockLimit: blockLimit
    };
  }

  // 7. All checks passed
  return {
    canReceiveNewRides: true,
    rideAccessStatus: 'ACTIVE',
    reason: 'ACTIVE',
    bengaliReason: 'সক্রিয় - নতুন রাইড পাওয়ার জন্য প্রস্তুত',
    isCommissionLimitReached: false,
    isAdminSuspended: false,
    commissionBalance: balance,
    commissionBlockLimit: blockLimit
  };
}

// In-memory guard to prevent concurrent executions for the exact same ride
const inProgressRideCommissions = new Set<string>();

/**
 * Record 10% commission on a completed ride.
 * - The final Total Booking Amount of every completed ride is used to calculate Chalo Platform Commission.
 * - Chalo Commission = Final Booking Amount × 10% (e.g. ₹100 booking = ₹10 commission, ₹150 = ₹15, ₹200 = ₹20).
 * - Commission is added to the existing Driver Commission Due balance in users and wallets collections.
 * - Multi-layer duplicate prevention ensures the same completed ride is never double-charged.
 */
export async function recordCompletedRideCommission(
  rideId: string,
  options?: {
    forceFare?: number;
    forceDriverId?: string;
    forceDriverName?: string;
  }
): Promise<{
  success: boolean;
  alreadyProcessed?: boolean;
  commissionAmount: number;
  newCommissionBalance: number;
  isCommissionBlocked: boolean;
}> {
  if (!rideId) {
    return { success: false, commissionAmount: 0, newCommissionBalance: 0, isCommissionBlocked: false };
  }

  // Guard against concurrent invocations for the exact same ride in the same session
  if (inProgressRideCommissions.has(rideId)) {
    console.log(`[Chalo Commission] Commission calculation for ride ${rideId} is already in-flight.`);
    return { success: true, alreadyProcessed: true, commissionAmount: 0, newCommissionBalance: 0, isCommissionBlocked: false };
  }
  inProgressRideCommissions.add(rideId);

  try {
    const rideRef = doc(db, 'rides', rideId);
    const rideSnap = await getDoc(rideRef);

    if (!rideSnap.exists()) {
      console.error(`Ride ${rideId} not found`);
      return { success: false, commissionAmount: 0, newCommissionBalance: 0, isCommissionBlocked: false };
    }

    const ride = rideSnap.data() as Ride;

    // 1. Primary Idempotency Check: Ride already marked commissionProcessed
    if (ride.commissionProcessed) {
      console.log(`[Chalo Commission] Ride ${rideId} commission already processed. Skipping duplicate calculation.`);
      return {
        success: true,
        alreadyProcessed: true,
        commissionAmount: ride.commissionAmount || calculateChaloCommission(getRideBookingAmount(ride, options?.forceFare)),
        newCommissionBalance: 0,
        isCommissionBlocked: false
      };
    }

    // 2. Secondary Idempotency Check: Transaction ledger check
    // Prevents duplicate commission deduction if ride doc was not updated during a previous interrupted run
    const existingTxQuery = query(
      collection(db, 'commission_transactions'),
      where('rideId', '==', rideId),
      where('type', '==', 'COMMISSION_DEDUCTION')
    );
    const existingTxSnap = await getDocs(existingTxQuery);
    if (!existingTxSnap.empty) {
      console.log(`[Chalo Commission] Transaction for ride ${rideId} already exists in ledger. Marking ride processed.`);
      const existingTxAmount = existingTxSnap.docs[0].data()?.amount || 0;
      await updateDoc(rideRef, {
        status: RideStatus.COMPLETED,
        commissionProcessed: true,
        commissionAmount: existingTxAmount,
        updatedAt: Date.now()
      });
      return {
        success: true,
        alreadyProcessed: true,
        commissionAmount: existingTxAmount,
        newCommissionBalance: 0,
        isCommissionBlocked: false
      };
    }

    const driverId = options?.forceDriverId || ride.driverId;
    if (!driverId) {
      console.error(`Ride ${rideId} has no driver assigned`);
      return { success: false, commissionAmount: 0, newCommissionBalance: 0, isCommissionBlocked: false };
    }

    const driverName = options?.forceDriverName || ride.driverName || 'Driver';

    // 3. Final Total Booking Amount of completed ride
    const finalBookingAmount = getRideBookingAmount(ride, options?.forceFare);

    // 4. Chalo Commission = Final Booking Amount × 10%
    // Examples: ₹100 booking = ₹10, ₹150 booking = ₹15, ₹200 booking = ₹20
    const commissionAmount = calculateChaloCommission(finalBookingAmount);

    const settings = await getGlobalCommissionSettings();

    // 5. Mark ride as completed and commission processed atomically
    const now = Date.now();
    await updateDoc(rideRef, {
      status: RideStatus.COMPLETED,
      finalFare: finalBookingAmount,
      commissionProcessed: true,
      commissionAmount,
      commissionRate: 0.10,
      commissionStatus: 'DUE',
      completedAt: ride.completedAt || now,
      updatedAt: now
    });

    // 6. Update Driver User Document (users collection)
    // Add the commission to the existing Driver Commission Due balance
    const driverUserRef = doc(db, 'users', driverId);
    const driverSnap = await getDoc(driverUserRef);
    const driverData = driverSnap.exists() ? (driverSnap.data() as Partial<UserProfile>) : {};

    const currentCommissionDue = Math.max(0, driverData.commissionBalance ?? 0);
    const newCommissionBalance = currentCommissionDue + commissionAmount;
    const totalDue = (driverData.totalCommissionDue ?? 0) + commissionAmount;
    const totalIncome = (driverData.totalRideIncome ?? 0) + finalBookingAmount;
    const totalRides = (driverData.totalRides ?? 0) + 1;
    const blockLimit = driverData.commissionBlockLimit ?? settings.commissionBlockLimit ?? DEFAULT_COMMISSION_BLOCK_LIMIT;
    const isCommissionBlocked = newCommissionBalance >= blockLimit;

    await setDoc(driverUserRef, {
      uid: driverId,
      commissionBalance: newCommissionBalance,
      totalCommissionDue: totalDue,
      totalRideIncome: totalIncome,
      totalRides,
      commissionBlocked: isCommissionBlocked,
      commissionBlockLimit: blockLimit,
      updatedAt: now
    }, { merge: true });

    // 7. Add Commission Transaction Record in ledger
    await addDoc(collection(db, 'commission_transactions'), {
      driverId,
      driverName,
      rideId,
      amount: commissionAmount,
      bookingAmount: finalBookingAmount,
      type: 'COMMISSION_DEDUCTION',
      paymentMethod: 'AUTO_DEDUCT',
      status: 'COMPLETED',
      description: `Chalo Platform Commission (10%) on Ride #${rideId.slice(0, 6)} - Booking Amount: ₹${finalBookingAmount}`,
      previousBalance: -currentCommissionDue,
      newBalance: -newCommissionBalance,
      previousDue: currentCommissionDue,
      newDue: newCommissionBalance,
      timestamp: now
    });

    // 8. Also keep wallets collection in sync (reusing existing driver wallet)
    const walletRef = doc(db, 'wallets', driverId);
    await setDoc(walletRef, {
      driverId,
      driverName,
      balance: -newCommissionBalance,
      pendingCommission: newCommissionBalance,
      totalEarned: totalIncome,
      isBlocked: isCommissionBlocked,
      commissionBlockLimit: blockLimit,
      updatedAt: now
    }, { merge: true });

    return {
      success: true,
      commissionAmount,
      newCommissionBalance,
      isCommissionBlocked
    };
  } catch (err) {
    console.error('Error recording completed ride commission:', err);
    return { success: false, commissionAmount: 0, newCommissionBalance: 0, isCommissionBlocked: false };
  } finally {
    inProgressRideCommissions.delete(rideId);
  }
}

// Throttling and debounce guard for syncUnprocessedCompletedRides
const activeSyncSet = new Set<string>();
const lastDriverSyncTimestamp = new Map<string, number>();

/**
 * Self-healing: Check for any completed rides assigned to this driver that
 * have not had their 10% commission processed yet, and process them.
 * Throttled to at most once per 60s per driver, limited to 15 recent rides.
 */
export async function syncUnprocessedCompletedRides(driverId: string): Promise<number> {
  if (!driverId) return 0;

  const now = Date.now();
  const lastSync = lastDriverSyncTimestamp.get(driverId) || 0;
  if (activeSyncSet.has(driverId) || (now - lastSync < 60000)) {
    return 0;
  }

  activeSyncSet.add(driverId);
  lastDriverSyncTimestamp.set(driverId, now);

  try {
    const q = query(
      collection(db, 'rides'),
      where('driverId', '==', driverId),
      where('status', '==', RideStatus.COMPLETED),
      limit(15)
    );
    const snap = await getDocs(q);
    let count = 0;
    for (const d of snap.docs) {
      const ride = d.data() as Ride;
      if (!ride.commissionProcessed) {
        console.log(`Processing missing commission for completed ride ${d.id}`);
        const bookingAmount = getRideBookingAmount(ride);
        await recordCompletedRideCommission(d.id, {
          forceFare: bookingAmount,
          forceDriverId: driverId,
          forceDriverName: ride.driverName
        });
        count++;
      }
    }
    return count;
  } catch (err) {
    console.error('Error syncing unprocessed completed rides:', err);
    return 0;
  } finally {
    activeSyncSet.delete(driverId);
  }
}

/**
 * Process a verified commission payment made by driver through Cashfree.
 * IDEMPOTENT: Checks orderId in transactions to prevent duplicate balance reductions.
 */
export async function processCashfreeCommissionPayment(paymentData: {
  driverId: string;
  driverName: string;
  amount: number;
  orderId: string;
  paymentSessionId?: string;
  paymentMethod?: string;
}): Promise<{
  success: boolean;
  alreadyProcessed?: boolean;
  newCommissionBalance: number;
  isBlocked: boolean;
}> {
  try {
    const { driverId, driverName, amount, orderId, paymentSessionId, paymentMethod = 'Cashfree' } = paymentData;

    // Idempotency check: If this order has already been credited, do not reduce balance twice
    const txQuery = query(
      collection(db, 'commission_transactions'),
      where('orderId', '==', orderId),
      where('status', '==', 'COMPLETED')
    );
    const existingTx = await getDocs(txQuery);
    if (!existingTx.empty) {
      console.log(`Payment order ${orderId} already processed. Skipping duplicate deduction.`);
      const driverRef = doc(db, 'users', driverId);
      const driverSnap = await getDoc(driverRef);
      const bal = driverSnap.data()?.commissionBalance ?? 0;
      const limit = driverSnap.data()?.commissionBlockLimit ?? DEFAULT_COMMISSION_BLOCK_LIMIT;
      return { success: true, alreadyProcessed: true, newCommissionBalance: bal, isBlocked: bal >= limit };
    }

    // Fetch driver record
    const driverRef = doc(db, 'users', driverId);
    const driverSnap = await getDoc(driverRef);
    const driverData = driverSnap.exists() ? (driverSnap.data() as Partial<UserProfile>) : {};

    const currentBalance = driverData.commissionBalance ?? 0;
    const newCommissionBalance = Math.max(0, currentBalance - amount);
    const totalPaid = (driverData.totalCommissionPaid ?? 0) + amount;
    const blockLimit = driverData.commissionBlockLimit ?? DEFAULT_COMMISSION_BLOCK_LIMIT;
    const isBlocked = newCommissionBalance >= blockLimit;

    // Update driver user document
    await setDoc(driverRef, {
      commissionBalance: newCommissionBalance,
      totalCommissionPaid: totalPaid,
      commissionBlocked: isBlocked,
      updatedAt: Date.now()
    }, { merge: true });

    // Record verified transaction in ledger
    await addDoc(collection(db, 'commission_transactions'), {
      driverId,
      driverName,
      amount,
      orderId,
      paymentSessionId: paymentSessionId || '',
      type: 'COMMISSION_PAYMENT',
      paymentMethod,
      status: 'COMPLETED',
      verificationResult: 'VERIFIED_SUCCESS',
      description: `Commission Payment of ₹${amount} via ${paymentMethod} (Order: ${orderId})`,
      timestamp: Date.now()
    });

    // Keep wallets collection in sync
    const walletRef = doc(db, 'wallets', driverId);
    await setDoc(walletRef, {
      driverId,
      driverName,
      balance: -newCommissionBalance,
      pendingCommission: newCommissionBalance,
      totalCommissionPaid: totalPaid,
      isBlocked,
      updatedAt: Date.now()
    }, { merge: true });

    return {
      success: true,
      newCommissionBalance,
      isBlocked
    };
  } catch (err) {
    console.error('Error processing Cashfree commission payment:', err);
    return { success: false, newCommissionBalance: 0, isBlocked: false };
  }
}

/**
 * Toggle driver manual admin ride access (ACTIVE / SUSPENDED)
 */
export async function toggleDriverAdminRideAccess(
  driverId: string, 
  currentAccess: 'ACTIVE' | 'SUSPENDED' = 'ACTIVE'
): Promise<'ACTIVE' | 'SUSPENDED'> {
  const newAccess = currentAccess === 'SUSPENDED' ? 'ACTIVE' : 'SUSPENDED';
  const userRef = doc(db, 'users', driverId);
  const walletRef = doc(db, 'wallets', driverId);

  await setDoc(userRef, {
    adminRideAccess: newAccess,
    updatedAt: Date.now()
  }, { merge: true });

  await setDoc(walletRef, {
    adminRideAccess: newAccess,
    updatedAt: Date.now()
  }, { merge: true });

  return newAccess;
}

/**
 * Admin Manual Driver Wallet Recharge / Commission Adjustment
 * Deducts the recharged amount directly from driver's outstanding commission balance.
 * No real money payment / No Cashfree. Purely an authorized administrative credit adjustment.
 */
export async function processAdminManualRecharge({
  driverId,
  driverName,
  amount,
  adminId,
  adminEmail,
  note
}: {
  driverId: string;
  driverName: string;
  amount: number;
  adminId: string;
  adminEmail?: string;
  note?: string;
}): Promise<{
  success: boolean;
  previousDue: number;
  remainingDue: number;
  isBlocked: boolean;
  isAdminSuspended: boolean;
  error?: string;
}> {
  try {
    if (!amount || amount <= 0) {
      return {
        success: false,
        previousDue: 0,
        remainingDue: 0,
        isBlocked: false,
        isAdminSuspended: false,
        error: 'Please enter a valid recharge amount greater than 0'
      };
    }

    // Fetch current driver profile
    const driverRef = doc(db, 'users', driverId);
    const driverSnap = await getDoc(driverRef);
    if (!driverSnap.exists()) {
      return {
        success: false,
        previousDue: 0,
        remainingDue: 0,
        isBlocked: false,
        isAdminSuspended: false,
        error: 'Driver profile not found'
      };
    }

    const driverData = driverSnap.data() as Partial<UserProfile>;
    const previousDue = driverData.commissionBalance ?? 0;
    const remainingDue = Math.max(0, previousDue - amount);
    const totalPaid = (driverData.totalCommissionPaid ?? 0) + amount;
    const blockLimit = driverData.commissionBlockLimit ?? DEFAULT_COMMISSION_BLOCK_LIMIT;
    const isBlocked = remainingDue >= blockLimit;
    const isAdminSuspended = driverData.adminRideAccess === 'SUSPENDED';

    const now = Date.now();

    // 1. Update driver user profile:
    // IMPORTANT: Keep adminRideAccess exactly as is (do not override manual Admin suspension)
    await setDoc(driverRef, {
      commissionBalance: remainingDue,
      totalCommissionPaid: totalPaid,
      commissionBlocked: isBlocked,
      updatedAt: now
    }, { merge: true });

    // 2. Update driver wallet document
    const walletRef = doc(db, 'wallets', driverId);
    await setDoc(walletRef, {
      driverId,
      driverName: driverData.displayName || driverName,
      balance: -remainingDue,
      pendingCommission: remainingDue,
      totalCommissionPaid: totalPaid,
      isBlocked,
      adminRideAccess: driverData.adminRideAccess || 'ACTIVE',
      updatedAt: now
    }, { merge: true });

    // 3. Record verified transaction in commission_transactions
    await addDoc(collection(db, 'commission_transactions'), {
      driverId,
      driverName: driverData.displayName || driverName,
      amount,
      type: 'ADMIN_MANUAL_RECHARGE',
      paymentMethod: 'ADMIN_ADJUSTMENT',
      status: 'COMPLETED',
      timestamp: now,
      adminId,
      adminEmail: adminEmail || '',
      previousBalance: -previousDue,
      newBalance: -remainingDue,
      note: note || `Admin Manual Recharge by ${adminEmail || 'Admin'}`,
      description: `Admin Manual Recharge: Credited ₹${amount}. Previous Due: ₹${previousDue}, Remaining Due: ₹${remainingDue}`,
      verificationResult: 'ADMIN_AUTHORIZED'
    });

    // 4. Log in admin activity logs
    await addDoc(collection(db, 'activity_logs'), {
      adminId,
      adminEmail: adminEmail || 'Admin',
      action: 'DRIVER_MANUAL_RECHARGE',
      details: `Recharged ₹${amount} for driver ${driverData.displayName || driverName} (ID: ${driverId}). Previous Due: ₹${previousDue}, New Due: ₹${remainingDue}`,
      timestamp: now
    });

    return {
      success: true,
      previousDue,
      remainingDue,
      isBlocked,
      isAdminSuspended
    };
  } catch (err: any) {
    console.error('Error processing Admin Manual Recharge:', err);
    return {
      success: false,
      previousDue: 0,
      remainingDue: 0,
      isBlocked: false,
      isAdminSuspended: false,
      error: err?.message || 'Failed to process admin recharge'
    };
  }
}

/**
 * Legacy compatibility functions
 */
export async function getDriverWallet(driverId: string, driverName: string = 'Driver'): Promise<DriverWallet> {
  const walletRef = doc(db, 'wallets', driverId);
  const snap = await getDoc(walletRef);

  if (snap.exists()) {
    return snap.data() as DriverWallet;
  }

  const initialWallet: DriverWallet = {
    driverId,
    driverName,
    balance: 0,
    totalEarned: 0,
    totalCommissionPaid: 0,
    pendingCommission: 0,
    isBlocked: false,
    updatedAt: Date.now()
  };

  try {
    await setDoc(walletRef, initialWallet);
  } catch (err) {
    console.error('Failed to create initial wallet document:', err);
  }

  return initialWallet;
}

export function calculateCommission(fare: number): number {
  return calculateChaloCommission(fare);
}

export async function recordRideCommission(
  driverId: string,
  driverName: string,
  rideId: string,
  fare: number,
  ratePercent: number = DEFAULT_COMMISSION_PERCENT
): Promise<{ success: boolean; commissionAmount: number; newBalance: number }> {
  const res = await recordCompletedRideCommission(rideId, {
    forceFare: fare,
    forceDriverId: driverId,
    forceDriverName: driverName
  });
  return {
    success: res.success,
    commissionAmount: res.commissionAmount,
    newBalance: -res.newCommissionBalance
  };
}

export async function rechargeDriverWallet(
  driverId: string,
  driverName: string,
  amount: number,
  paymentMethod: 'UPI' | 'CASH' | 'NET_BANKING' = 'UPI'
): Promise<{ success: boolean; newBalance: number }> {
  const res = await processCashfreeCommissionPayment({
    driverId,
    driverName,
    amount,
    orderId: `MANUAL_RECHARGE_${Date.now()}`,
    paymentMethod
  });
  return {
    success: res.success,
    newBalance: -res.newCommissionBalance
  };
}
